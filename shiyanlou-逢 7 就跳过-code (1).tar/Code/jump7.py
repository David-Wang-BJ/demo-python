for a in range(1,101):
	if a%7 != 0 and a%10 !=7 and a//10 != 7:
		print(a, end ='\n')
